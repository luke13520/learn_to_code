#include <unistd.h>

void  ft_putchar(char c) {
  write(1, &c, 1);
}


void ft_print_alphabet(void) {
  // print the alphabet please
  char mycar;
     
  mycar='a';
  while (mycar <= 'z') {  
    ft_putchar(mycar);
    ft_putchar('\n');
    mycar =mycar+1;
  }
}

void main(void) {
    ft_print_alphabet();
}