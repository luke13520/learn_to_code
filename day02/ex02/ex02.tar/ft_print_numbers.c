#include <unistd.h>

void  ft_putchar(char c) {
  write(1, &c, 1);
}


void ft_print_number(void) {
  // print the number please
  int mycar;

  mycar= '0' ;

  while (mycar <= '9') {  
    ft_putchar(mycar);
    ft_putchar('\n');
    mycar =mycar+1;
  }
}

void main(void) {
    ft_print_number();
}