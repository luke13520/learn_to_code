#include <unistd.h>

void  ft_putchar(char c) {
  write(1, &c, 1);
}
void ft_putnbr(int nb) {

     //int nb;
     
     //for(nb = 420){
     ft_putchar('0'+nb/10);
     ft_putchar('0'+nb%10);
     
     ft_putchar('\n');


    // nb = 32767
    // 1 character at the time with ft_putchar
    // decompose nb into a list of characters
    // from 32767 -> ft_putchar('3'); ft_putchar('2'), ..
    // 32767 -> 7
    // 30 / 10 = 3; 32 / 10 = 3; 32 % 10 = 2;
    // 32767 % 10 -> 7;

    // 117%10=11 < no, it's 7
    // print 7
    // 117 / 10 = 11; 11 % 10 = 1
    // print 1
    // 11 / 10 = 1; 1 % 10 = 1
    // print 1
    // Result: we printed 711

  // print the number please

     //}
}

  void main(void) {
    ft_putnbr(42);
}
